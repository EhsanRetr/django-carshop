CARS_BRANDS = (
    ('bmw', 'BMW'),
    ('mercedes benz', 'Mercedes Benz'),
    ('audi', 'Audi'),
    ('dodge','Dodge'),
    ('subaru', 'Subaru'),
    ('tesla', 'Tesla'),
    ('jaguar', 'Jaguar'),
    ('land rover', 'Land Rover'),
    ('bentley', 'Bentley'),
    ('bugatti', 'Bugatti'),
    ('ferrari', 'Ferrari'),
    ('lamborghini', 'Lamborghini'),
    ('honda', 'Honda'),
    ('toyota', 'Toyota'),
    ('chevrolet', 'Chevrolet'),
    ('porsche', 'Porsche'),
    ('lexuse', 'Lexuse')
)
TRANSMISSION_OPTIONS = (
    ('automatic', 'Automatic'),
    ('manual', 'Manual'),
)
